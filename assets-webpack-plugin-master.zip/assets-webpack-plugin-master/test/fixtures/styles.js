require('./stylesheet1.css')
require('./stylesheet2.css')
